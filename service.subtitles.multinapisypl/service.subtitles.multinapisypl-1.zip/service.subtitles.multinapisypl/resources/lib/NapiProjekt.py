# *-* coding: utf-8 *-*

import base64
import os
import re
import sys
import traceback
import time
from urllib.parse import urljoin
from xml.dom import minidom

import requests

import dom_parser
import xbmc
import xbmcaddon
import PTN

__addon__ = xbmcaddon.Addon()
__scriptname__ = __addon__.getAddonInfo('name')

# ============================================================
# Publiczny FlareSolverr – nie wymaga komputera w sieci lokalnej
# ============================================================
DEFAULT_FLARESOLVERR_URL = "https://napi.oops.wtf"

def _fs_server_url():
    """Adres z ustawień Kodi, z zachowaniem domyślnego serwera."""
    try:
        custom = (__addon__.getSetting("fs_server_url") or "").strip().rstrip("/")
        if custom:
            if not custom.startswith(("http://", "https://")):
                xbmc.log("### [NapiProjekt] - Invalid FS URL scheme; using default", xbmc.LOGWARNING)
            else:
                if custom.endswith("/v1"):
                    custom = custom[:-3].rstrip("/")
                return custom
    except Exception:
        pass
    return DEFAULT_FLARESOLVERR_URL

# Jedna sesja FlareSolverr na wyszukiwanie; w razie odmowy zwykle zapytania.
_ACTIVE_FS_SESSION = None
_FS_SERVER_ERROR = False


def _create_fs_session():
    """Sesja publiczna jest opcjonalna: nie kazdy serwer na nia pozwala."""
    import uuid
    session_id = "napi-" + uuid.uuid4().hex
    started = time.monotonic()
    try:
        r = requests.post(
            _fs_server_url().rstrip("/") + "/v1",
            json={"cmd": "sessions.create", "session": session_id},
            timeout=8,
        )
        r.raise_for_status()
        result = r.json()
        if result.get("status") == "ok":
            session_id = result.get("session") or session_id
            xbmc.log("### [NapiProjekt] - FS session created %.2fs" %
                     (time.monotonic() - started), xbmc.LOGINFO)
            return session_id
    except Exception as exc:
        xbmc.log("### [NapiProjekt] - FS session unavailable: %s" %
                 str(exc)[:160], xbmc.LOGINFO)
    return None


def _destroy_fs_session(session_id):
    if not session_id:
        return
    try:
        requests.post(
            _fs_server_url().rstrip("/") + "/v1",
            json={"cmd": "sessions.destroy", "session": session_id},
            timeout=5,
        )
    except Exception:
        pass



def _is_challenge_html(html):
    """Rozpoznaje stronę weryfikacyjną zamiast właściwej zawartości."""
    if not html:
        return False
    sample = html[:30000].lower()
    markers = (
        "<title>cierpliwości", "<title>just a moment", "<title>attention required",
        "cf-chl-", "challenge-platform", "checking your browser",
        "weryfikacja przeglądarki", "verify you are human",
    )
    return any(marker in sample for marker in markers)


def _flaresolverr_request(method, url, post_data=None):
    """Wyłącznie publiczny FlareSolverr."""
    from urllib.parse import urlencode
    global _FS_SERVER_ERROR
    if method.upper() == "POST":
        payload = {
            "cmd": "request.post", "url": url,
            "postData": urlencode(post_data or {}), "maxTimeout": 30000,
        }
    else:
        payload = {"cmd": "request.get", "url": url, "maxTimeout": 30000}

    if _ACTIVE_FS_SESSION:
        payload["session"] = _ACTIVE_FS_SESSION

    for server_name, server in (("configured", _fs_server_url()),):
        started = time.monotonic()
        try:
            resp = requests.post(server.rstrip("/") + "/v1", json=payload, timeout=36)
            resp.raise_for_status()
            data = resp.json()
            solution = data.get("solution") or {}
            html = solution.get("response") or ""
            status_code = solution.get("status", "unknown")
            challenge = _is_challenge_html(html)
            xbmc.log("### [NapiProjekt] - FS %s %s %.2fs status=%s page_http=%s challenge=%s" % (
                server_name, method, time.monotonic() - started, data.get("status"), status_code, challenge), xbmc.LOGINFO)
            if data.get("status") == "ok" and html and not challenge and int(status_code) < 400:
                _FS_SERVER_ERROR = False
                return html
            _FS_SERVER_ERROR = True
            xbmc.log("### [NapiProjekt] - FS %s invalid response, trying next server: %s" % (
                server_name, str(data.get("message", ""))[:160]), xbmc.LOGWARNING)
        except Exception as exc:
            _FS_SERVER_ERROR = True
            xbmc.log("### [NapiProjekt] - FS %s failed after %.2fs: %s" % (
                server_name, time.monotonic() - started, str(exc)[:200]), xbmc.LOGWARNING)
    # Do not issue a second potentially 36-second request after failure.
    # The prior version could take over a minute when a public worker stalls.
    xbmc.log("### [NapiProjekt] - Public FlareSolverr failed", xbmc.LOGERROR)
    return ""


def _get(url, **kwargs):
    """GET przez FlareSolverr."""
    return _FlareSolverrResponse(_flaresolverr_request("GET", url))


def _post(url, data=None, **kwargs):
    """POST przez FlareSolverr."""
    return _FlareSolverrResponse(_flaresolverr_request("POST", url, post_data=data or {}))


class _FlareSolverrResponse:
    """
    Uproszczony obiekt odpowiedzi imitujący requests.Response,
    żeby reszta kodu działała bez zmian.
    """
    def __init__(self, text):
        self.text = text or ""
        self.status_code = 200 if text else 503

    def json(self):
        import json
        return json.loads(self.text)


def _cache_file():
    import xbmcvfs
    folder = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, 'movie_url_cache_v24.json')


def _cache_key(item):
    import hashlib, json
    fields = [item.get(k, '') for k in ('title', 'year', 'tvshow', 'season', 'episode', 'file_original_path')]
    # Path can contain unique stream tokens; only use stable Trakt IDs when present.
    path = str(fields.pop())
    ids = re.findall(r'(?:movieTraktId|showTraktId|seasonNumber|episodeNumber)=([^&]+)', path)
    raw = json.dumps([str(x) for x in fields] + ids, ensure_ascii=False)
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def _cached_url(item):
    import json
    try:
        with open(_cache_file(), 'r', encoding='utf-8') as f:
            cache = json.load(f)
        entry = cache.get(_cache_key(item), {})
        url = entry.get('url', '')
        if (time.time() - entry.get('at', 0) < 30 * 86400
                and url.startswith('https://www.napiprojekt.pl/napisy')):
            return url
    except Exception:
        pass
    return None


def _save_cached_url(item, url):
    import json
    if not url.startswith('https://www.napiprojekt.pl/napisy'):
        return
    try:
        path = _cache_file()
        try:
            with open(path, 'r', encoding='utf-8') as f:
                cache = json.load(f)
        except Exception:
            cache = {}
        cache = {k: v for k, v in cache.items() if time.time() - v.get('at', 0) < 30 * 86400}
        cache[_cache_key(item)] = {'url': url, 'at': time.time()}
        with open(path + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(cache, f)
        os.replace(path + '.tmp', path)
    except Exception as exc:
        xbmc.log('### [NapiProjekt] - cache write failed: %s' % str(exc)[:100], xbmc.LOGWARNING)



def _subtitle_cache_file():
    return os.path.join(os.path.dirname(_cache_file()), 'subtitle_results_cache_v24.json')


def _load_subtitle_results(item):
    import json
    try:
        with open(_subtitle_cache_file(), 'r', encoding='utf-8') as f:
            cache = json.load(f)
        entry = cache.get(_cache_key(item), {})
        rows = entry.get('results')
        if (isinstance(rows, list) and rows
                and time.time() - entry.get('at', 0) < 24 * 3600
                and all(isinstance(row, dict) and
                        all(k in row for k in ('language', 'label', 'link_hash', 'sync', 'data', 'downloads'))
                        for row in rows)):
            return rows
    except Exception:
        pass
    return None


def _save_subtitle_results(item, rows):
    import json
    if not rows:
        return
    try:
        path = _subtitle_cache_file()
        try:
            with open(path, 'r', encoding='utf-8') as f:
                cache = json.load(f)
            if not isinstance(cache, dict):
                cache = {}
        except Exception:
            cache = {}
        now = time.time()
        cache = {k: v for k, v in cache.items()
                 if isinstance(v, dict) and now - v.get('at', 0) < 24 * 3600}
        cache[_cache_key(item)] = {'at': now, 'results': rows}
        with open(path + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False)
        os.replace(path + '.tmp', path)
    except Exception as exc:
        xbmc.log('### [NapiProjekt] - subtitle cache write failed: %s' %
                 str(exc)[:120], xbmc.LOGWARNING)


def _clear_current_np_cache(item):
    """Remove only this search key from original NP caches; leave other films intact."""
    import json
    cache_key = _cache_key(item)
    for path in (_cache_file(), _subtitle_cache_file()):
        try:
            if not os.path.isfile(path):
                continue
            with open(path, 'r', encoding='utf-8') as f:
                contents = json.load(f)
            if not isinstance(contents, dict) or cache_key not in contents:
                continue
            del contents[cache_key]
            tmp = path + '.multinapisypl.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(contents, f, ensure_ascii=False)
            os.replace(tmp, path)
            xbmc.log('### [NapiProjekt] - TEST removed cached entry from ' + os.path.basename(path), xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log('### [NapiProjekt] - TEST cache cleanup failed: %s' % str(exc)[:120], xbmc.LOGWARNING)


class NapiProjektKatalog:
    def __init__(self):
        self.download_url = "https://napiprojekt.pl/api/api-napiprojekt3.php"
        self.base_url = "https://www.napiprojekt.pl"
        self.search_url = "/ajax/search_catalog.php"

    def log(self, msg=None, ex=None):
        if ex:
            level = xbmc.LOGERROR
            msg = traceback.format_exc()
        else:
            level = xbmc.LOGINFO
        xbmc.log((u"### [%s] - %s" % (__scriptname__, msg)), level=level)

    def notify(self, msg):
        xbmc.executebuiltin((u'Notification(%s,%s)' % (__scriptname__, msg)))

    def try_get_org_title(self, title):
        start_index = title.find("(")
        end_index = title.find(")")
        if start_index != -1 and end_index != -1:
            return title[start_index + 1:end_index]
        return None

    def find_indexed_subtitle_page(self, titles, year):
        """Fallback: locate public NP film pages without fixed catalog IDs.

        The normal NP catalog remains the primary source. Search engines are
        optional; only exact full-title slugs with plausible years are accepted.
        """
        import html
        from urllib.parse import unquote, urlparse

        def normalize(value):
            value = html.unescape(unquote(str(value or '')))
            value = re.sub(r'\(?\s*(?:19|20)\d{2}\s*\)?', ' ', value)
            value = re.sub(r'[^\w]+', ' ', value, flags=re.UNICODE)
            return ' '.join(value.casefold().split())

        wanted = []
        for title in titles:
            cleaned = normalize(title)
            if len(cleaned) >= 5 and cleaned not in wanted:
                wanted.append(cleaned)
        if not wanted:
            return None
        # Search only the primary title, not every alias, to bound latency.
        primary = next((str(t) for t in titles if normalize(t) == wanted[0]), '')
        query = 'site:napiprojekt.pl/napisy1 "' + primary + '"'
        # Google's HTML search sometimes exposes URLs only in /url?q= links.
        # The second independent search is Bing RSS, with a short timeout.
        engines = (
            ('google', 'https://www.google.com/search', {'q': query, 'num': 10}),
            ('bing', 'https://www.bing.com/search', {'q': query, 'format': 'rss'}),
        )
        for engine, endpoint, params in engines:
            try:
                response = requests.get(endpoint, params=params,
                    headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36'},
                    timeout=5)
                response.raise_for_status()
                page = html.unescape(response.text)
                # URL may be encoded in HTML attributes, RSS links or Google redirects.
                page = page.replace('\\u003d', '=').replace('\\u0026', '&')
                matches = re.findall(r'(?:https?%3A%2F%2F|https?://)?(?:www\.)?napiprojekt\.pl(?:%2F|/)(?:napisy1|napisy-)[^\s<>"\']{0,240}', page, re.I)
                for raw in matches:
                    link = unquote(html.unescape(raw)).split('&')[0]
                    match = re.search(r'(?:napisy1[^/]*-dla-|napisy-)(\d+)-([^\s<>"\'?#]+)', link, re.I)
                    if not match:
                        continue
                    film_id, slug = match.groups()
                    slug = slug.rstrip(').,;') if not slug.endswith(')') else slug
                    years = re.findall(r'(?<!\d)((?:19|20)\d{2})(?!\d)', slug)
                    if year and str(year).isdigit() and years and all(abs(int(y) - int(year)) > 2 for y in years):
                        continue
                    slug_title = normalize(slug.replace('-', ' '))
                    if slug_title not in wanted:
                        continue
                    url = 'https://www.napiprojekt.pl/napisy1,1,1-dla-%s-%s' % (film_id, slug)
                    self.log('NP indexed %s verified film id=%s title=%s' % (engine, film_id, slug_title))
                    return url.encode('utf-8')
                self.log('NP indexed %s: no verified matching film' % engine)
            except Exception as exc:
                self.log('NP indexed %s unavailable: %s' % (engine, str(exc)[:120]))
        return None

    def find_subtitle_page(self, item, counter=0):
        if not any((True for x in item["3let_language"] if x in ["pl", "pol"])):
            self.log('Only polish supported')
            self.notify('Only Polish supported')
            return None

        if item['tvshow'] or ('showTraktId' in item["file_original_path"] and 'showTraktId=null' not in item["file_original_path"]):
            if 'showTraktId' in item["file_original_path"]:
                showTraktId = re.findall("showTraktId=(.*?)&", item["file_original_path"])[0]
                title_to_find = _get(
                    "https://trakt.tv/shows/%s" % showTraktId
                ).text  # FlareSolverr nie obsługuje allow_redirects=False, bierzemy tekst i parsujemy URL
                # fallback – wyciągnij tytuł z URL przekierowania jeśli dostępny
                query_kind = 1
                query_year = ''
            else:
                title_to_find = item['tvshow']
                query_kind = 1
                query_year = ''
        else:
            if 'movieTraktId' in item["file_original_path"]:
                movieTraktId = re.findall("movieTraktId=(.*?)&", item["file_original_path"])[0]
                title_to_find = requests.get(
                    "https://trakt.tv/movies/%s" % movieTraktId,
                    allow_redirects=False
                ).headers['location'].split("/")[-1].replace("-", " ")
                query_kind = 2
                query_year = re.findall(r"\d{4}", title_to_find)[-1]
            else:
                parsed = PTN.parse(item['title'])
                try:
                    title_to_find = parsed['title']
                except Exception:
                    title_to_find = item['title']
                try:
                    query_year = str(parsed['year'])
                except Exception:
                    query_year = item['year']
                query_kind = 2

        post = {
            'queryKind': query_kind,
            'queryString': self.getsearch(title_to_find),
            'queryYear': query_year,
            'associate': ''
        }
        self.log('searching for movie: ' + str(post))

        url = self.base_url + self.search_url
        search_started = time.monotonic()
        response = _post(url, data=post)
        self.log("TIMING catalog search %.2fs" % (time.monotonic() - search_started))
        subs = response.text
        self.log('HTTP status: %d' % response.status_code)
        self.log('Response preview: ' + subs[:300].replace('\n', ' '))
        rows = self.parseDOM_base(subs, 'a', attrs={'class': 'movieTitleCat'})

        # Najpierw sprawdź WSZYSTKIE wyniki z pierwszego zapytania.
        # Tytuł oryginalny z Kodi jest już w item['title']; nie trzeba TMDb/Filmweb.
        titles = [title_to_find, item.get('title', ''), item.get('videoplayer_title', '')] + (item.get('alternate_titles') or [] if query_kind == 2 else [])
        seen = set()
        titles = [t for t in titles if t and not (self.get_clean(t).casefold() in seen or seen.add(self.get_clean(t).casefold()))]

        def matched_page(candidate_rows):
            for candidate in candidate_rows:
                parsed_titles = self.parseDOM(candidate.content, 'h3')
                candidate_title = parsed_titles[0] if parsed_titles else candidate.attrs.get('tytul', '')
                if not candidate_title:
                    candidate_title = candidate.attrs.get('tytul', '')
                # The catalog's `tytul` attribute is the actual Polish title;
                # the h3 often appends a foreign alias and '- 1988r.'.
                catalog_name = candidate.attrs.get('tytul', '')
                normalized = self.get_clean(candidate_title).lower()
                # The catalog title often includes a release year.
                normalized_no_year = re.sub(r"\s*\(?\b(?:19|20)\d{2}\b\)?\s*$", "", normalized).strip(" -–—()")
                # The catalog may list identically titled films from different years.
                # Reject explicit year mismatches even if the title matches.
                if query_kind == 2 and str(query_year).isdigit():
                    # Prefer the film year encoded in its href, not years in alternative titles.
                    href_year = re.search(r'\(((?:19|20)\d{2})\)', candidate.attrs.get('href', ''))
                    years = [href_year.group(1)] if href_year else re.findall(r'(?<!\d)((?:19|20)\d{2})(?!\d)', candidate_title)
                    if years and all(abs(int(y) - int(query_year)) > 2 for y in years):
                        self.log('NP reject catalog movie year: %s expected %s' % (candidate_title, query_year))
                        continue
                for wanted in titles:
                    # Movie titles must match in full. A substring search incorrectly
                    # matched e.g. The Invitation with Zaproszenie dla rewolwerowca.
                    wanted_norm = self.get_clean(wanted).lower().strip()
                    # Allow a catalog title with the original title in parentheses.
                    catalog_variants = [normalized, normalized_no_year, self.get_clean(catalog_name).lower().strip()]
                    for parenthetical in re.findall(r'\(([^()]*)\)', candidate_title):
                        catalog_variants.append(self.get_clean(parenthetical).lower().strip())
                    # Restore the broader v1.0.38 matching for TV series only.
                    # Keep strict movie matching to avoid The Invitation false positives.
                    is_tv = bool(item.get('tvshow')) or ('showTraktId' in item.get('file_original_path', '') and 'showTraktId=null' not in item.get('file_original_path', ''))
                    tv_words = [w for w in wanted_norm.split() if w]
                    def canonical(text):
                        return re.sub(r"^(?:the|a|an)\s+", "", text.casefold()).strip()
                    matches = (bool(tv_words) and self.contains_all_words(normalized, tv_words)) if is_tv else (bool(wanted_norm) and canonical(wanted_norm) in {canonical(v) for v in catalog_variants})
                    if matches:
                        self.log('Found: ' + candidate_title)
                        result = urljoin(self.base_url, candidate.attrs['href'])
                        if item['tvshow'] or ('showTraktId' in item['file_original_path'] and 'showTraktId=null' not in item['file_original_path']):
                            if 'seasonNumber' in item['file_original_path']:
                                season_match = re.findall('seasonNumber=(.*?)&', item['file_original_path'])
                                episode_match = re.findall('episodeNumber=([^&]*)', item['file_original_path'])
                                season = season_match[0] if season_match else item['season']
                                episode = episode_match[0] if episode_match else item['episode']
                            else:
                                season, episode = item['season'], item['episode']
                            result += '-s' + str(season).zfill(2) + 'e' + str(episode).zfill(2)
                        return result.replace('napisy-', 'napisy1,1,1-dla-', 1).encode('utf-8')
            return None

        result = matched_page(rows)
        if result:
            return result
        # The website's own interactive catalog uses queryKind=0.
        # Query that exact mode before the older kind=2 fallbacks.
        # A 200 response may still be empty; validate every candidate title and year.
        if query_kind == 2:
            interactive_post = dict(post, queryKind=0, queryYear='')
            self.log('NP interactive catalog fallback: %s' % interactive_post['queryString'])
            interactive_response = _post(url, data=interactive_post)
            interactive_rows = self.parseDOM_base(interactive_response.text, 'a', attrs={'class': 'movieTitleCat'})
            result = matched_page(interactive_rows)
            if result:
                return result
        # Szybka strategia: maksymalnie 5 dodatkowych zapytań do katalogu.
        # Nie mnożymy roczników i nie odpytujemy Google/Bing. Odpowiedzi
        # weryfikujemy identycznie jak pierwsze zapytanie (tytuł + rok).
        attempts = []
        used = {(post['queryString'].casefold(), str(query_year))}

        def add_attempt(title, year, reason):
            title = self.getsearch(title or '').strip()
            key = (title.casefold(), str(year))
            if title and key not in used:
                used.add(key)
                attempts.append((title, str(year), reason))

        primary = post['queryString']
        fallback = item.get('videoplayer_title') or ''
        add_attempt(primary, '', 'primary without year')
        add_attempt(fallback, '', 'Kodi title without year')
        if fallback and self.getsearch(fallback).casefold() != primary.casefold():
            add_attempt(fallback, query_year, 'Kodi title with year')

        # Tylko pierwsze sensowne alternatywne tytuły zapisane alfabetem
        # łacińskim; inne pisma potrafiły generować dziesiątki zapytań.
        aliases = []
        for alias in (item.get('alternate_titles') or []):
            if not alias or not re.search(r'[A-Za-z]', alias):
                continue
            if re.search(r'[\u0400-\u052f\u0590-\u08ff\u1100-\u11ff\u3040-\u30ff\u3400-\u9fff]', alias):
                continue
            clean = self.getsearch(alias).strip()
            if clean and clean.casefold() not in {primary.casefold(), self.getsearch(fallback).casefold()}:
                aliases.append(clean)
        for alias in aliases[:2]:
            add_attempt(alias, query_year, 'Latin alias with year')
            add_attempt(alias, '', 'Latin alias without year')

        # Gdy wyszukiwarka NP nie indeksuje pełnego tytułu, pojedyncze
        # charakterystyczne słowo może ujawnić właściwą pozycję.
        tokens = re.findall(r"[^\W_]+", primary, flags=re.UNICODE)
        stopwords = {'the', 'and', 'for', 'with', 'from', 'this', 'that', 'saint', 'film', 'movie'}
        distinctive = sorted((t for t in tokens if len(t) >= 5 and t.casefold() not in stopwords),
                             key=lambda t: (-len(t), t.casefold()))
        if distinctive:
            add_attempt(distinctive[0], '', 'distinctive word')

        for title, year, reason in attempts[:5]:
            self.log('NP fast fallback: %s title=%s year=%s' % (reason, title, year))
            retry_post = dict(post, queryString=title, queryYear=year)
            retry_started = time.monotonic()
            response = _post(url, data=retry_post)
            self.log('NP fast fallback %.2fs' % (time.monotonic() - retry_started))
            retry_rows = self.parseDOM_base(response.text, 'a', attrs={'class': 'movieTitleCat'})
            result = matched_page(retry_rows)
            if result:
                return result
            # The interactive catalog can index entries that the old movie mode misses.
            if query_kind == 2 and title.casefold() != primary.casefold():
                interactive_post = dict(retry_post, queryKind=0, queryYear='')
                self.log('NP interactive alias fallback: %s' % title)
                interactive_response = _post(url, data=interactive_post)
                interactive_rows = self.parseDOM_base(interactive_response.text, 'a', attrs={'class': 'movieTitleCat'})
                result = matched_page(interactive_rows)
                if result:
                    return result
        self.log('No matching catalog title found')
        return None

    def _is_synced(self, item, video_file_size, video_time=0):
        import datetime
        import time
        sync = False
        try:
            totalTime = float(xbmc.Player().getTotalTime())
            x = time.strptime(str(video_time).split('.')[0], '%H:%M:%S')
            milliseconds = float(float(str(video_time).split('.')[1]) / 1000)
            video_time = int(
                datetime.timedelta(hours=x.tm_hour, minutes=x.tm_min, seconds=x.tm_sec).total_seconds()
            ) + milliseconds
            if abs(totalTime - video_time) <= 0.5:
                sync = True
            if len(video_file_size) > 0:
                video_file_size = float(re.findall(r"([\d.]+)", video_file_size)[0])
                file_size = round(item["file_original_size"] / float(1048576), 2)
                if abs(file_size - video_file_size) <= 2:
                    sync = True
        except Exception:
            return sync
        return sync

    def search(self, item):
        _clear_current_np_cache(item)
        subtitle_list = []
        total_started = time.monotonic()
        self.log("B:")
        cached_results = None  # MultiNapisyPl TEST: bypass subtitle results cache
        if cached_results is not None:
            self.log("RESULT CACHE HIT %d entries; %.2fs" % (
                len(cached_results), time.monotonic() - total_started))
            return sorted(cached_results, key=lambda x: (x['sync'], x['downloads']), reverse=True)
        self.log("RESULT CACHE MISS")
        global _ACTIVE_FS_SESSION, _FS_SERVER_ERROR
        _FS_SERVER_ERROR = False
        cached_url = None  # MultiNapisyPl TEST: bypass catalog URL cache
        self.log('CACHE %s' % ('HIT' if cached_url else 'MISS'))
        _ACTIVE_FS_SESSION = None if cached_url else _create_fs_session()
        try:
            if cached_url:
                url = cached_url
            else:
                page_result = self.find_subtitle_page(item)
                self.log("TIMING title lookup %.2fs" % (time.monotonic() - total_started))
                self.log(page_result)
                if not page_result:
                    self.notify('Movie not found')
                    return subtitle_list
                url = page_result.decode('utf-8')
            self.log('trying to get subtitles list')
            listing_started = time.monotonic()
            # Najpierw oryginalny adres katalogu zwrocony przez wyszukiwarke.
            # Wczesniejsza wersja bezwarunkowo zmieniala 1,1,1 na 1,7,0.
            page = _get(url).text
            if not self.parseDOM(page, 'tbody') and "napisy1,1,1" in url:
                self.log("Original catalog page has no tbody; trying legacy listing URL")
                page = _get(url.replace("napisy1,1,1", "napisy1,7,0")).text
            self.log("TIMING subtitles page %.2fs" % (time.monotonic() - listing_started))
            page = self.parseDOM(page, 'tbody')
            if len(page) > 0:
                if not cached_url:
                    pass  # MultiNapisyPl TEST: do not write catalog URL cache
                rows = self.parseDOM(page, 'tr')
                for row in rows:
                    # Pomijamy wiersze nagłówkowe i separatory – muszą mieć link z hashem
                    hrefs = self.parseDOM(row, 'a', ret='href')
                    if not hrefs:
                        continue
                    link_hash = hrefs[0].replace('napiprojekt:', '')

                    cols = self.parseDOM(row, 'p')
                    # Wiersz musi mieć co najmniej 7 kolumn (po usunięciu pierwszej)
                    if len(cols) < 7:
                        continue
                    cols.pop(0)
                    # Buduj kazdy element osobno, tak jak w Napisy24.
                    # Czas dostaje osobny fragment [B][COLOR white]...[/COLOR][/B].
                    duration_re = re.compile(r'(?<!\d)(\d{1,2}:\d{2}:\d{2})(?:[.,]\d+)?(?!\d)')
                    label_parts = []
                    for col in cols[:-1]:
                        match = duration_re.search(col)
                        if match:
                            before = col[:match.start()]
                            after = col[match.end():]
                            formatted = '[B][COLOR white]' + match.group(1) + '[/COLOR][/B]'
                            label_parts.append(before + formatted + after)
                        else:
                            label_parts.append(col)
                    label = ' | '.join(label_parts)
                    try:
                        int(cols[5])
                    except Exception:
                        continue
                    subtitle_list.append({
                        'language': 'pol',
                        'label': label,
                        'link_hash': link_hash,
                        'sync': self._is_synced(item, cols[0], cols[2]),
                        'data': cols[4],
                        'downloads': int(cols[5])
                    })
            else:
                self.notify('No subtitles available')
        except Exception as e:
            self.notify('Search error, check log')
            self.log(ex=e)
        finally:
            session_id = _ACTIVE_FS_SESSION
            _ACTIVE_FS_SESSION = None
            _destroy_fs_session(session_id)
        self.log("TIMING total search %.2fs; results=%d" % (time.monotonic() - total_started, len(subtitle_list)))
        if subtitle_list:
            pass  # MultiNapisyPl TEST: do not write subtitle results cache
        return sorted(subtitle_list, key=lambda x: (x['sync'], x['downloads']), reverse=True)

    def get_clean(self, title):
        if title is None:
            return
        title = re.sub('&#(\d+);', '', title)
        title = re.sub('(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = title.replace('&', 'and')
        title = re.sub(r'\n|([[].+?[]])|([(]\d.*?[)])|\s(vs|v[.])\s|(:|;|-|[\u2013]|"|,|\'|\_|\.|\?)', '', title).lower()
        if title.startswith('the'):
            title = title[3:]
        return self.normalize(title)

    def contains_word(self, str_to_check, word):
        return str(word).lower() in str(str_to_check).lower()

    def contains_all_words(self, str_to_check, words):
        for word in words:
            if not self.contains_word(str_to_check, word):
                return False
        return True

    def parseDOM_base(self, html, name, attrs):
        if attrs:
            attrs = dict((key, re.compile(value + ('$' if value else ''))) for (key, value) in attrs.items())
        results = dom_parser.parse_dom(html, name, attrs)
        return results

    def parseDOM(self, html, name='', attrs=None, ret=False):
        results = self.parseDOM_base(html, name, attrs)
        if ret:
            results = [result.attrs[ret.lower()] for result in results]
        else:
            results = [result.content for result in results]
        return results

    def getsearch(self, title):
        if title is None:
            return ''
        title = title.lower()
        title = re.sub('&#(\d+);', '', title)
        title = re.sub('(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub(r'\\|/|-|[\u2013]|:|;|\*|\?|"|\'|<|>|\|', '', title)
        return title

    def normalize(self, title):
        return str(title).lower() \
            .replace('ą', 'a').replace('ę', 'e').replace('ć', 'c') \
            .replace('ź', 'z').replace('ż', 'z').replace('ó', 'o') \
            .replace('ł', 'l').replace('ń', 'n').replace('ś', 's')

    def download(self, md5hash, filename, language="PL"):
        try:
            values = {
                "mode": "1",
                "client": "NapiProjektPython",
                "client_ver": "0.1",
                "downloaded_subtitles_id": md5hash,
                "downloaded_subtitles_txt": "1",
                "downloaded_subtitles_lang": language
            }
            self.log('Downloading subs: ' + str(values))

            # Pobieranie napisów przez FlareSolverr (endpoint API też jest chroniony)
            response = _post(self.download_url, data=values)
            response_text = response.text

            DOMTree = minidom.parseString(response_text)
            cNodes = DOMTree.childNodes
            if cNodes[0].getElementsByTagName("status"):
                text = base64.b64decode(
                    cNodes[0].getElementsByTagName("subtitles")[0]
                              .getElementsByTagName("content")[0]
                              .childNodes[0].data
                )
                filename = filename[:filename.rfind(".")] + ".txt"
                open(filename, "wb").write(text)
                return filename

        except Exception as e:
            self.notify('Download error, check log')
            self.log(ex=e)

        return None
