# -*- coding: utf-8 -*-
from http.cookiejar import LWPCookieJar
from urllib.request import HTTPCookieProcessor, build_opener, Request, urlopen
from urllib.parse import urlencode, quote_plus, urlsplit, unquote
import json
import os
import re
import unicodedata
import zlib
import bs4
import uuid
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui

__addon__ = xbmcaddon.Addon()
__version__ = __addon__.getAddonInfo("version")  # Module version
__scriptname__ = __addon__.getAddonInfo("name")
__language__ = __addon__.getLocalizedString
__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo("profile"))
__temp__ = xbmcvfs.translatePath(os.path.join(__profile__, "temp", ""))

regexHelper = re.compile("\W+", re.UNICODE)


def normalizeString(str):
    return unicodedata.normalize("NFKD", str)


def log(msg):
    xbmc.log(("### [%s] - %s" % (__scriptname__, msg)), level=xbmc.LOGDEBUG)


def notify(msg_id):
    xbmcgui.Dialog().notification(__scriptname__, __language__(msg_id))


def clean_title(item):
    title = os.path.splitext(os.path.basename(item["title"]))
    tvshow = os.path.splitext(os.path.basename(item["tvshow"]))

    if len(title) > 1:
        if re.match(r"^\.[a-z]{2,4}$", title[1], re.IGNORECASE):
            item["title"] = title[0]
        else:
            item["title"] = "".join(title)
    else:
        item["title"] = title[0]

    if len(tvshow) > 1:
        if re.match(r"^\.[a-z]{2,4}$", tvshow[1], re.IGNORECASE):
            item["tvshow"] = tvshow[0]
        else:
            item["tvshow"] = "".join(tvshow)
    else:
        item["tvshow"] = tvshow[0]

    # Removes country identifier at the end
    item["title"] = re.sub(r"\([^\)]+\)\W*$", "", item["title"]).strip()
    item["tvshow"] = re.sub(r"\([^\)]+\)\W*$", "", item["tvshow"]).strip()


def parse_rls_title(item):
    title = regexHelper.sub(" ", item["title"])
    tvshow = regexHelper.sub(" ", item["tvshow"])

    groups = re.findall(
        r"(.*?) (\d{4})? ?(?:s|season|)(\d{1,2})(?:e|episode|x|\n)(\d{1,2})",
        title,
        re.I,
    )

    if len(groups) == 0:
        groups = re.findall(
            r"(.*?) (\d{4})? ?(?:s|season|)(\d{1,2})(?:e|episode|x|\n)(\d{1,2})",
            tvshow,
            re.I,
        )

    if len(groups) > 0 and len(groups[0]) >= 3:
        title, year, season, episode = groups[0]
        item["year"] = str(int(year)) if len(year) == 4 else year

        item["tvshow"] = regexHelper.sub(" ", title).strip()
        item["season"] = str(int(season))
        item["episode"] = str(int(episode))
        log("TV Parsed Item: %s" % (item,))

    else:
        groups = re.findall(r"(.*?)(\d{4})", item["title"], re.I)
        if len(groups) > 0 and len(groups[0]) >= 1:
            title = groups[0][0]
            item["title"] = regexHelper.sub(" ", title).strip()
            item["year"] = groups[0][1] if len(groups[0]) == 2 else item["year"]

            log("MOVIE Parsed Item: %s" % (item,))


class NapisyHelper:
    BASE_URL = "https://napisy24.pl"

    def __init__(self):
        self.urlHandler = URLHandler()

    def get_subtitle_list(self, item):
        # Kodi sometimes supplies season/episode but no TVshowtitle. Manual search
        # succeeds because it explicitly fills tvshow; replicate that automatically.
        candidates = []
        def add(value):
            value = (value or "").strip()
            if value and value.casefold() not in [x.casefold() for x in candidates]:
                candidates.append(value)

        # Streaming URLs often end in opaque UUIDs and access tokens, not release names.
        # Never use query strings or opaque stream IDs as title candidates.
        from urllib.parse import urlsplit, unquote
        raw_path = item.get("file_original_path", "") or ""
        if raw_path.lower().startswith(("http://", "https://")):
            filename = os.path.basename(unquote(urlsplit(raw_path).path))
            if re.fullmatch(r"[0-9a-fA-F-]{32,36}", filename):
                filename = ""
        else:
            filename = os.path.basename(raw_path)
        filename = re.sub(r"\.[^.]+$", "", filename)
        filename = re.sub(r"[._]+", " ", filename)
        episode_match = re.search(r"(?i)\bS(\d{1,2})\s*E(\d{1,2})\b", filename)
        if not episode_match:
            episode_match = re.search(r"(?i)\b(\d{1,2})x(\d{1,2})\b", filename)
        if episode_match:
            filename_title = filename[:episode_match.start()].strip(" -.")
        else:
            filename_title = re.split(r"(?i)\b(?:19\d{2}|20\d{2}|720p|1080p|2160p|web.?dl|bluray|remux)\b", filename)[0].strip()

        is_episode = bool(item.get("tvshow")) or bool(item.get("season") and item.get("episode")) or bool(episode_match)
        attempt_base = dict(item)
        if episode_match:
            if not str(attempt_base.get("season") or "").isdigit():
                attempt_base["season"] = str(int(episode_match.group(1)))
            if not str(attempt_base.get("episode") or "").isdigit():
                attempt_base["episode"] = str(int(episode_match.group(2)))

        if is_episode:
            add(item.get("tvshow"))
            add(item.get('rpc_showtitle'))
            # Resolve original names using stable external IDs, not hard-coded aliases.
            if item.get('automatic', True):
                for original in self._resolve_original_titles(item):
                    add(original)
            add(filename_title)
            # OriginalTitle is sometimes the episode name, so use it only if
            # the filename cannot identify a series or matches it.
            if not filename_title:
                add(item.get("title"))
        else:
            add(item.get("title"))
            for variant in item.get('alternate_titles', []):
                add(variant)
            if item.get('automatic', True) and not item.get('skip_n24_tmdb_lookup'):
                for original in self._resolve_original_movie_titles(item):
                    add(original)
            add(filename_title)

        for value in list(candidates):
            add(re.sub(r"\s*\([^)]*\)\s*$", "", value).strip())
            add(re.sub(r"\s*[-:]\s*.*$", "", value).strip())

        # Independent HTTP handlers per worker: urllib opener headers and cookie jars
        # are mutable and must not be shared across simultaneous requests.
        selected = candidates[:12]
        def search_candidate(candidate):
            attempt = dict(attempt_base)
            attempt["tvshow" if is_episode else "title"] = candidate
            helper = NapisyHelper()
            try:
                found = helper._search_tvshow(attempt) if is_episode else helper._search_movie(attempt)
                return found or []
            except Exception as exc:
                log("Search failed for %r: %s" % (candidate, exc))
                return []
        # executor.map preserves original candidate order and therefore the
        # ordering and full set of results of the sequential implementation.
        with ThreadPoolExecutor(max_workers=min(4, len(selected) or 1)) as pool:
            groups = list(pool.map(search_candidate, selected))
        search_results = []
        seen = set()
        for found in groups:
            for result in found:
                key = (str(result.get("id")), result.get("release"))
                if key not in seen:
                    seen.add(key)
                    search_results.append(result)
        # Do not log stream URLs, tokens, or private file paths.
        log("Subtitle search completed: %d title candidates; %d results" % (len(candidates), len(search_results)))
        return self._build_subtitle_list(search_results, attempt_base)

    def _resolve_original_titles(self, item):
        ids = item.get('uniqueids') or {}
        if not isinstance(ids, dict):
            ids = {}
        names = []
        def fetch(url, headers=None):
            try:
                req = Request(url, headers=headers or {'User-Agent': 'Kodi-Napisy24/3.0.11'})
                with urlopen(req, timeout=4) as response:
                    return json.loads(response.read(1024 * 1024).decode('utf-8'))
            except Exception as exc:
                log('Title lookup unavailable: %s' % type(exc).__name__)
                return {}
        imdb = ids.get('imdb') or xbmc.getInfoLabel('VideoPlayer.IMDBNumber')
        if imdb and re.fullmatch(r'tt\d+', str(imdb)):
            data = fetch('https://api.tvmaze.com/lookup/shows?imdb=' + quote_plus(str(imdb)))
            if isinstance(data, dict) and data.get('name'):
                names.append(data['name'])
        # TMDb lookup handles translated titles. A personal API key is optional.
        key = (__addon__.getSetting('tmdb_api_key') or '').strip()
        tmdb_id = ids.get('tmdb')
        if key:
            root = 'https://api.themoviedb.org/3/'
            auth = {'Authorization': 'Bearer ' + key, 'User-Agent': 'Kodi-Napisy24/3.0.11'} if key.startswith('eyJ') else None
            def tmdb(endpoint, params=None):
                params = dict(params or {})
                if not auth:
                    params['api_key'] = key
                url = root + endpoint + ('?' + urlencode(params) if params else '')
                return fetch(url, auth)
            if tmdb_id and str(tmdb_id).isdigit():
                data = tmdb('tv/' + str(tmdb_id))
                if isinstance(data, dict) and data.get('original_name'):
                    names.append(data['original_name'])
            if not names and item.get('tvshow'):
                data = tmdb('search/tv', {'query': item['tvshow'], 'language': 'pl-PL', 'first_air_date_year': item.get('year', '')})
                results = data.get('results', []) if isinstance(data, dict) else []
                # Only accept a clear exact match of the localized title.
                norm = lambda x: ''.join(c for c in unicodedata.normalize('NFKD', x or '').casefold() if not unicodedata.combining(c)).strip()
                matches = [r for r in results if norm(r.get('name')) == norm(item['tvshow'])]
                if len(matches) == 1 and matches[0].get('original_name'):
                    names.append(matches[0]['original_name'])
        return names

    def _resolve_original_movie_titles(self, item):
        """Resolve movie original titles using stable IDs or an exact Polish title.

        Never select a fuzzy search hit: wrong matches can contaminate results.
        """
        key = (__addon__.getSetting('tmdb_api_key') or '').strip()
        if not key:
            return []
        ids = item.get('uniqueids') or {}
        if not isinstance(ids, dict):
            ids = {}
        headers = {'User-Agent': 'Kodi-Napisy24/3.0.12'}
        if key.startswith('eyJ'):
            headers['Authorization'] = 'Bearer ' + key
        def fetch(endpoint, params=None):
            params = dict(params or {})
            if not key.startswith('eyJ'):
                params['api_key'] = key
            url = 'https://api.themoviedb.org/3/' + endpoint
            if params:
                url += '?' + urlencode(params)
            try:
                with urlopen(Request(url, headers=headers), timeout=4) as response:
                    return json.loads(response.read(1024 * 1024).decode('utf-8'))
            except Exception as exc:
                log('Movie title lookup unavailable: %s' % type(exc).__name__)
                return {}
        def normalized(value):
            return re.sub(r'\s+', ' ', ''.join(
                c for c in unicodedata.normalize('NFKD', value or '').casefold()
                if not unicodedata.combining(c))).strip()
        def get_original(movie):
            if not isinstance(movie, dict):
                return []
            original = (movie.get('original_title') or '').strip()
            return [original] if original and normalized(original) != normalized(item.get('title')) else []

        tmdb_id = ids.get('tmdb')
        if tmdb_id and str(tmdb_id).isdigit():
            found = get_original(fetch('movie/' + str(tmdb_id)))
            if found:
                return found
        imdb_id = ids.get('imdb') or xbmc.getInfoLabel('VideoPlayer.IMDBNumber')
        if imdb_id and re.fullmatch(r'tt\d+', str(imdb_id)):
            data = fetch('find/' + str(imdb_id), {'external_source': 'imdb_id'})
            matches = data.get('movie_results', []) if isinstance(data, dict) else []
            if len(matches) == 1:
                found = get_original(matches[0])
                if found:
                    return found
        title = (item.get('title') or '').strip()
        if not title:
            return []
        data = fetch('search/movie', {'query': title, 'language': 'pl-PL'})
        results = data.get('results', []) if isinstance(data, dict) else []
        matches = [movie for movie in results if normalized(movie.get('title')) == normalized(title)]
        year = str(item.get('year') or '')
        if year.isdigit() and len(year) == 4:
            dated = [movie for movie in matches if str(movie.get('release_date') or '').startswith(year)]
            if dated:
                matches = dated
        if len(matches) == 1:
            return get_original(matches[0])
        return []

    def download(self, id):
        ## Cleanup temp dir, we recomend you download/unzip your subs in temp folder and
        ## pass that to XBMC to copy and activate
        if xbmcvfs.exists(__temp__):
            (dirs, files) = xbmcvfs.listdir(__temp__)
            for file in files:
                xbmcvfs.delete(os.path.join(__temp__, file))
        else:
            xbmcvfs.mkdirs(__temp__)

        subtitle_type_map = ["sru", "sr", "tmp", "mdvd", "mpl2"]
        subs_format_raw = __addon__.getSetting("subs_format") or "0"
        try:
            subs_format = int(subs_format_raw)
        except (ValueError, TypeError):
            subs_format = 0
        if not 0 <= subs_format < len(subtitle_type_map):
            subs_format = 0

        query = {"napisId": id, "typ": subtitle_type_map[subs_format]}

        f = self.urlHandler.request(
            self.BASE_URL + "/download", query, referer=self.BASE_URL
        )

        if f is None and self.login(True):
            f = self.urlHandler.request(
                self.BASE_URL + "/download", query, referer=self.BASE_URL
            )

        if f is None:
            return

        zip_filename = os.path.join(__temp__, "%s.zip" % str(uuid.uuid4()))

        with open(zip_filename, "wb") as subFile:
            subFile.write(f)
        subFile.close()

        exts = [".srt", ".sub", ".txt"]
        zip_filepath = "zip://%s" % quote_plus(zip_filename)
        (dirs, files) = xbmcvfs.listdir(zip_filepath)
        subtitle_list = []
        for file in files:
            if os.path.splitext(file)[1] in exts:
                filename_dest = os.path.join(__temp__, file)
                flag = xbmcvfs.copy(zip_filepath + "/" + file, filename_dest)
                if flag:
                    subtitle_list.append(filename_dest)

        return subtitle_list

    def login(self, notify_success=False):
        login_form = self.urlHandler.request(self.BASE_URL + "/cb-login")

        html = bs4.BeautifulSoup(login_form, "html.parser")
        form = html.find("form", attrs={"id": "login-form"})
        inputs = form.find_all("input", attrs={"type": "hidden"})

        username = __addon__.getSetting("username")
        password = __addon__.getSetting("password")
        post_data = {"username": username, "passwd": password, "Submit": ""}

        for input in inputs:
            post_data[input["name"]] = input["value"]

        content = self.urlHandler.request(self.BASE_URL + "/cb-login", data=post_data)

        if content.find(self.BASE_URL + "/cb-logout") > -1:
            self.urlHandler.save_cookie()

            if notify_success:
                notify(32014)

            return True
        else:
            notify(32005)
            return False

    @staticmethod
    def _subtitle_duration(source):
        """Read a duration advertised in a Napisy24 result; never guess it."""
        if not source:
            return ""
        if isinstance(source, dict):
            for key in ("czas_trwania", "czas", "duration", "runtime", "time"):
                value = source.get(key)
                if value:
                    found = NapisyHelper._subtitle_duration(str(value))
                    if found:
                        return found
            source = " ".join(str(v) for v in source.values() if isinstance(v, (str, int)))
        soup = bs4.BeautifulSoup(str(source), "html.parser")
        for tag in soup.find_all(True):
            for key in ("data-duration", "data-runtime", "data-czas", "data-czas-trwania"):
                if tag.has_attr(key):
                    value = NapisyHelper._subtitle_duration(str(tag[key]))
                    if value:
                        return value
        text = soup.get_text(" ", strip=True)
        # Prefer a duration explicitly labelled by the provider.
        match = re.search(r"(?i)(?:czas\s*trwania|długość|duration|runtime)\s*[:\-]?\s*((?:\d{1,2}:)?\d{1,2}:\d{2})\b", text)
        if not match:
            # Only use an unlabelled timestamp when it includes hours, minutes and seconds.
            match = re.search(r"(?<!\d)(\d{1,2}:\d{2}:\d{2})(?!\d)", text)
        if not match:
            return ""
        parts = [int(x) for x in match.group(1).split(":")]
        if len(parts) == 2:
            parts.insert(0, 0)
        h, m, sec = parts
        if m >= 60 or sec >= 60 or h > 12:
            return ""
        return "%02d:%02d:%02d" % (h, m, sec)

    @staticmethod
    def _subtitle_author(source):
        """Use only an explicitly labelled subtitle author."""
        if not source:
            return ""
        if isinstance(source, dict):
            for key in ("autor", "author", "uploader", "nick", "username"):
                value = source.get(key)
                if isinstance(value, (str, int)) and str(value).strip():
                    return str(value).strip()
            source = source.get("table") or ""
        soup = bs4.BeautifulSoup(str(source), "html.parser")
        for tag in soup.find_all(True):
            for key in ("data-autor", "data-author", "data-uploader", "data-username"):
                value = tag.get(key)
                if value and str(value).strip():
                    return str(value).strip()
        # Napisy24 lists credited people in infoColumn4 in the same order
        # as infoColumn3: Tłumaczenie, Dopasowanie, Korekta.
        credits = soup.select_one(".infoColumn4")
        if credits:
            # Preserve empty <br> slots: get_text(strip=True) would shift credits.
            from bs4 import NavigableString
            slots = [""]
            for node in credits.descendants:
                if getattr(node, "name", None) == "br":
                    slots.append("")
                elif isinstance(node, NavigableString):
                    slots[-1] += str(node)
            translator = slots[0].strip() if slots else ""
            if translator and len(translator) <= 100:
                return translator
        text = soup.get_text(" ", strip=True)
        match = re.search(r"(?i)(?:autor(?: napisów)?|dodał|dodane przez|uploaded by)\s*[:：]\s*([^|,;]{2,45})", text)
        return match.group(1).strip() if match else ""

    # Search TV subtitles using the provider's existing endpoint.
    def _search_tvshow(self, item):
        results = []
        search_string = re.split(r"\s\(\w+\)$", item["tvshow"])[0]
        data = {"serial": search_string.lower(), "sezon": item["season"], "epizod": item["episode"]}
        payload = self.urlHandler.request(self.BASE_URL + "/run/pages/serial_napis.php", data=data)
        if not payload:
            return results
        if isinstance(payload, bytes):
            payload = payload.decode("utf-8", "replace")
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except (ValueError, TypeError):
                log("Unexpected TV search response")
                return results
        if not isinstance(payload, list):
            return results
        for result in payload:
            if not isinstance(result, dict) or not result.get("napisid"):
                continue
            table = result.get("table") or ""
            html = bs4.BeautifulSoup(table, "html.parser")
            versions = []
            for tag in html.find_all("h6", attrs={"data-wydanie": True}):
                versions.extend(tag.get("data-wydanie", "").split(";"))
            if not versions:
                versions = ["S%02dE%02d" % (int(item.get("season") or 0), int(item.get("episode") or 0))]
            duration = self._subtitle_duration(result) or self._subtitle_duration(table)
            author = self._subtitle_author(result) or self._subtitle_author(table)
            sizes = re.findall(r"[\d.,]+\s*MB", table)
            size = sizes[0] if sizes else ""
            for version in versions:
                if not version.strip():
                    continue
                title = str(result.get("serial") or search_string).title()
                results.append({"id": result["napisid"], "title": title,
                    "release": "%s.%s" % (regexHelper.sub(".", title), version.strip()),
                    "language": "pl", "duration": duration, "author": author, "video_file_size": size,
                    "downloads": int(result.get("pobran") or 0)})
        return results

    @staticmethod
    def _language_from_search_card(row):
        """Read the provider's language/flag metadata; never default to Polish.

        Unknown language is excluded in Polish-only search mode.
        """
        import os
        def classify(raw):
            v = str(raw or '').strip().lower()
            if not v:
                return None
            # Recognize explicit flag tokens, including flag icons and image paths.
            parts = re.split(r'[^a-z0-9]+', v)
            if any(t in ('eng', 'english', 'gb', 'uk', 'en') for t in parts):
                return 'en'
            if any(t in ('pol', 'polish', 'pl', 'polski', 'polskie') for t in parts):
                return 'pl'
            return None
        # Search the actual flag/icon first, not the release name or whole card.
        for node in row.find_all(True):
            attrs = node.attrs or {}
            candidates = []
            for attr in ('data-lang', 'data-language', 'data-jezyk', 'lang'):
                if attrs.get(attr): candidates.append(attrs[attr])
            if node.name in ('img', 'svg', 'use', 'i', 'span'):
                for attr in ('src', 'data-src', 'href', 'xlink:href', 'alt', 'title', 'aria-label'):
                    if attrs.get(attr): candidates.append(attrs[attr])
                for attr in ('class', 'id'):
                    val=attrs.get(attr)
                    if val: candidates.extend(val if isinstance(val,list) else [val])
            for candidate in candidates:
                lang=classify(candidate)
                if lang: return lang
        return None

    def _search_movie(self, item):
        results = []
        for page in (1, 2):
            query = {"page": page, "lang": 0, "search": item["title"], "typ": 1}
            content = self.urlHandler.request(self.BASE_URL + "/szukaj", query)
            if not content:
                break
            rows = bs4.BeautifulSoup(content, "html.parser").select("[data-napis-id]")
            if not rows:
                break
            for row in rows:
                napis_id = row.get("data-napis-id")
                title_tag = row.find("div", {"class": "uu_oo_uu"})
                if not napis_id or title_tag is None:
                    continue
                title = title_tag.get_text(" ", strip=True).title()
                # Some Napisy24 search cards contain an empty title div. Try
                # only title-bearing attributes/elements from the same card,
                # never infer the title from the query (substring search).
                if not title.strip():
                    candidates = []
                    for element in (title_tag, row):
                        for attr in ('data-title', 'data-tytul', 'title', 'aria-label'):
                            value = element.get(attr)
                            if isinstance(value, str) and value.strip():
                                candidates.append(value.strip())
                    for element in row.select('a[href*="/film/"], a[href*="/napisy/"], h2, h3, h4'):
                        value = element.get_text(' ', strip=True)
                        if value:
                            candidates.append(value)
                    title = next((v.title() for v in candidates if len(v) >= 2), '')
                    if not title:
                        log('N24 missing movie title: id=%r; no reliable fallback' % napis_id)
                        continue
                    log('N24 recovered movie title: id=%r title=%r' % (napis_id, title))
                info = row.find("div", {"class": "infoColumn2"})
                fields = [x.strip() for x in info.get_text("|", strip=True).split("|")] if info else []
                year = fields[0] if fields else ""
                card_language = self._language_from_search_card(row)
                if card_language != 'pl':
                    log('N24 FLAG FILTER: skipped id=%r language=%r' % (napis_id, card_language))
                    continue
                duration = self._subtitle_duration(str(row))
                author = self._subtitle_author(str(row))
                # Napisy24 /szukaj is a substring search. Filter results to the
                # exact film title and, when Kodi knows it, the exact release year.
                # This prevents e.g. "Vengeance" (2022) from returning dozens of
                # unrelated titles merely containing the word "vengeance".
                def title_key(value):
                    value = unicodedata.normalize("NFKD", str(value or "")).casefold()
                    value = "".join(c for c in value if not unicodedata.combining(c))
                    return re.sub(r"[^\w]+", " ", value, flags=re.UNICODE).strip()
                # Provider titles can include a trailing year, e.g. "Vengeance (2022)".
                # Kodi titles may also carry the year, so compare cleaned names.
                def movie_key(value):
                    value = re.sub(r"\s*[\[(](?:19|20)\d{2}[\])]\s*$", "", str(value or ""))
                    return title_key(value)
                wanted = movie_key(item.get("title"))
                found = movie_key(title)
                allowed_titles = item.get('alternate_titles') or [item.get('title')]
                allowed_keys = {movie_key(v) for v in allowed_titles if v}
                if wanted:
                    allowed_keys.add(wanted)
                if found not in allowed_keys:
                    # Search results can use an alias absent from TMDb's
                    # alternative_titles list. Accept only if an independent
                    # TMDb search resolves it to the exact same movie ID.
                    verifier = item.get('verify_n24_title')
                    verified = False
                    if callable(verifier):
                        try:
                            explicit_year = re.search(r"\b(?:19|20)\d{2}\b", str(year or ""))
                            verified = bool(verifier(title, explicit_year.group() if explicit_year else None))
                        except Exception as exc:
                            log('N24 identity verification error: %s' % type(exc).__name__)
                    if not verified:
                        log("N24 FILTER title: wanted=%r variants=%r found=%r raw=%r year=%r" % (wanted, sorted(allowed_keys), found, title, year))
                        continue
                expected_year = re.search(r"\b(?:19|20)\d{2}\b", str(item.get("year") or ""))
                # Only reject an explicitly different year. Napisy24 sometimes
                # omits the year or puts it in the title instead of the info field.
                found_year = re.search(r"\b(?:19|20)\d{2}\b", str(year or ""))
                if not found_year:
                    found_year = re.search(r"[\[(]((?:19|20)\d{2})[\])]\s*$", str(title))
                if expected_year and found_year:
                    provider_year = found_year.group(1) if found_year.lastindex else found_year.group()
                    year_delta = abs(int(expected_year.group()) - int(provider_year))
                    # A one- or two-year difference is possible between festival/original
                    # release and local distribution. Only tolerate it when the
                    # title already matched a known alias or TMDb verified the ID.
                    # Keep rejecting differences above two years (and unrelated titles).
                    if year_delta > 2:
                        log("N24 FILTER year: wanted=%r found=%r rawtitle=%r" % (expected_year.group(), provider_year, title))
                        continue
                    if 1 <= year_delta <= 2:
                        log("N24 ACCEPT year +/-2: wanted=%r found=%r rawtitle=%r" % (expected_year.group(), provider_year, title))
                log("N24 ACCEPT: title=%r year=%r id=%r" % (title, year, napis_id))
                releases_tag = row.find("div", attrs={"data-releases": True})
                releases = releases_tag.get("data-releases", "") if releases_tag else ""
                versions = re.split(r"<br\s*/?>", releases, flags=re.I) if releases else [""]
                for version in versions:
                    version = bs4.BeautifulSoup(version, "html.parser").get_text(" ", strip=True)
                    label = "%s.%s" % (regexHelper.sub(".", title), version) if version else title
                    if year and year != str(item.get("year") or ""):
                        label += " [%s]" % year
                    results.append({"id": napis_id, "title": title, "release": label,
                        "duration": duration, "author": author, "video_file_size": fields[4] if len(fields) > 4 else "",
                        "language": card_language, "downloads": 0})
        return results

    @staticmethod
    def _duration_seconds(value):
        """Parse provider/Kodi duration as H:MM:SS or MM:SS."""
        if not value:
            return None
        try:
            parts = [int(x) for x in str(value).strip().split(":")]
            if len(parts) == 3:
                h, m, sec = parts
                if m < 60 and sec < 60:
                    return h * 3600 + m * 60 + sec
            elif len(parts) == 2:
                m, sec = parts
                if sec < 60:
                    return m * 60 + sec
        except (ValueError, TypeError):
            pass
        return None

    @staticmethod
    def _playing_duration_seconds():
        """Prefer the actual player's total time; avoid treating unknown time as a match."""
        try:
            player = xbmc.Player()
            if player.isPlayingVideo():
                total = float(player.getTotalTime())
                if total > 60:
                    return total
        except (RuntimeError, ValueError, TypeError):
            pass
        try:
            return NapisyHelper._duration_seconds(xbmc.getInfoLabel("VideoPlayer.Duration"))
        except (RuntimeError, ValueError, TypeError):
            return None

    def _build_subtitle_list(self, search_results, item):
        results = []
        total_downloads = 0
        playing_duration = self._playing_duration_seconds()

        for result in search_results:
            lang3 = xbmc.convertLanguage(result["language"], xbmc.ISO_639_2)

            if lang3 in item["3let_language"]:
                total_downloads += result["downloads"]
                subtitle_duration = self._duration_seconds(result.get("duration"))
                duration_match = (
                    playing_duration is not None
                    and subtitle_duration is not None
                    and abs(playing_duration - subtitle_duration) <= 1.5
                )
                results.append(
                    {
                        "lang_index": item["3let_language"].index(lang3),
                        "filename": result["release"] + (" | [B][COLOR white]" + result["duration"] + "[/COLOR][/B]" if result.get("duration") else "") + (" | " + result["author"] if result.get("author") else ""),
                        "language_name": xbmc.convertLanguage(
                            result["language"], xbmc.ENGLISH_NAME
                        ),
                        "language_flag": result["language"],
                        "id": result["id"],
                        "rating": result["downloads"],
                        "sync": duration_match or self._is_synced(
                            item, result["video_file_size"], result["release"]
                        ),
                        "hearing_imp": False,
                        "is_preferred": lang3 == item["preferredlanguage"],
                    }
                )

        # Fix the rating
        if total_downloads:
            for it in results:
                it["rating"] = min(
                    int(round(it["rating"] / float(total_downloads), 1) * 8), 5
                )

        return sorted(
            results,
            key=lambda x: (x["sync"], x["is_preferred"], -x["lang_index"], x["rating"]),
            reverse=True,
        )

    def _is_synced(self, item, video_file_size, version):
        sync = False

        if len(video_file_size) > 0:
            matches = re.findall(r"([\d.,]+)\s*MB", video_file_size)
            video_file_size = float(matches[0].replace(",", ".")) if matches else -1
            file_size = round(item["file_original_size"] / float(1048576), 2)
            if file_size == video_file_size:
                sync = True

        if not sync:
            sync = self._calc_rating(version, item["file_original_path"]) >= 3.8

        return sync

    def _calc_rating(self, version, file_original_path):
        file_name = os.path.basename(file_original_path)
        folder_name = os.path.split(os.path.dirname(file_original_path))[-1]

        version = re.sub(r"\W+", ".", version).lower()
        file_name = re.sub(r"\W+", ".", file_name).lower()
        folder_name = re.sub(r"\W+", ".", folder_name).lower()
        log(
            "# Comparing Releases:\n [subtitle-rls] %s \n [filename-rls] %s \n [folder-rls] %s"
            % (version, file_name, folder_name)
        )

        version = version.split(".")
        file_name = file_name.split(".")[:-1]
        folder_name = folder_name.split(".")

        if len(file_name) > len(folder_name):
            diff_file = list(set(file_name) - set(version))
            rating = (1 - (len(diff_file) / float(len(file_name)))) * 5
        else:
            diff_folder = list(set(folder_name) - set(version))
            rating = (1 - (len(diff_folder) / float(len(folder_name)))) * 5

        log(
            "\n rating: %f (by %s)"
            % (
                round(rating, 1),
                "file" if len(file_name) > len(folder_name) else "folder",
            )
        )

        return round(rating, 1)


class URLHandler:
    def __init__(self):
        self.cookie_filename = os.path.join(__profile__, "cookiejar.txt")
        self.cookie_jar = LWPCookieJar(self.cookie_filename)
        if os.access(self.cookie_filename, os.F_OK):
            self.cookie_jar.load()

        self.opener = build_opener(HTTPCookieProcessor(self.cookie_jar))
        self.opener.addheaders = [
            ("Accept-Encoding", "gzip"),
            ("Accept-Language", "en-us,en;q=0.5"),
            ("Pragma", "no-cache"),
            ("Cache-Control", "no-cache"),
            (
                "User-Agent",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 11_2_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            ),
        ]

    def request(
        self,
        url,
        query_string=None,
        data=None,
        ajax=False,
        referer=None,
        cookie=None,
        decode_zlib=True,
    ):
        if data is not None:
            self.opener.addheaders += [
                ("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            ]
            data = urlencode(data).encode("utf-8")
        if query_string is not None:
            query_string = urlencode(query_string)
            url += "?" + query_string
        if ajax:
            self.opener.addheaders += [("X-Requested-With", "XMLHttpRequest")]
        if referer is not None:
            self.opener.addheaders += [("Referer", referer)]
        if cookie is not None:
            self.opener.addheaders += [("Cookie", cookie)]

        content = None
        log("Getting url: %s\nData: %s" % (url, data))
        try:
            response = self.opener.open(url, data)

            if response.code == 200:
                content = response.read()

                if decode_zlib and "gzip" in response.headers.get(
                    "content-encoding", ""
                ):
                    try:
                        content = zlib.decompress(content, 16 + zlib.MAX_WBITS)
                    except zlib.error:
                        pass

                if "application/json" in response.headers.get("content-type", ""):
                    content = json.loads(content)
                elif "text/html" in response.headers.get("content-type", ""):
                    content = content.decode("utf-8", "replace")

            response.close()
        except Exception as e:
            log("Failed to get url: %s\n%s" % (url, e))
            # Second parameter is the filename
        return content

    def save_cookie(self):
        self.cookie_jar.save()
