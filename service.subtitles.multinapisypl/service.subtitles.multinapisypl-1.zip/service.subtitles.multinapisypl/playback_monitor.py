# -*- coding: utf-8 -*-
"""Credential monitor plus conservative playback subtitle restore."""
import time
import xbmc, xbmcaddon
import login_monitor
from subtitle_cache import source_key, get_saved, log

ADDON = xbmcaddon.Addon('service.subtitles.multinapisypl')

class PlaybackMonitor(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.started_at = 0
        self.checked = False
        self.last_key = None

    def onAVStarted(self):
        self.started_at = time.monotonic()
        self.checked = False
        self.last_key = None

    def onPlayBackStopped(self):
        self.checked = True

    def onPlayBackEnded(self):
        self.checked = True

    def poll(self):
        if not ADDON.getSettingBool('auto_saved_subtitles') or not self.isPlayingVideo():
            return
        key = source_key()
        if not key:
            return
        if key != self.last_key:
            self.last_key = key
            self.started_at = time.monotonic()
            self.checked = False
        if self.checked or time.monotonic() - self.started_at < 2.5:
            return
        self.checked = True  # Never override later manual subtitle choices in this playback.
        saved = get_saved(key)
        if not saved:
            return
        try:
            # Respect subtitles already selected by Kodi or another addon.
            if self.getSubtitles() and self.isSubtitlesEnabled():
                log('Existing subtitles enabled; leaving them unchanged')
                return
        except Exception:
            pass
        try:
            self.setSubtitles(saved)
            self.showSubtitles(True)
            log('Restored saved subtitles')
        except Exception as e:
            log('Restore failed: ' + repr(e))

if __name__ == '__main__':
    import threading
    player = PlaybackMonitor()
    worker = threading.Thread(target=login_monitor.main, daemon=True)
    worker.start()
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        try:
            player.poll()
        except Exception as e:
            log('Monitor error: ' + repr(e))
        monitor.waitForAbort(0.8)
