# -*- coding: utf-8 -*-
"""Persistent, per-source subtitle selection for MultiNapisyPl."""
import os, json, hashlib, shutil, threading
from urllib.parse import urlsplit, urlunsplit
import xbmc, xbmcaddon, xbmcvfs

ADDON = xbmcaddon.Addon('service.subtitles.multinapisypl')
ROOT = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
STORE = os.path.join(ROOT, 'saved_subtitles')
LOCK = threading.RLock()
EXTENSIONS = ('.srt', '.sub', '.txt', '.ass', '.ssa', '.vtt')

def polish_filename(path):
    # Preserve the actual format. A .txt containing SRT cues can safely be
    # exposed as .pl.srt; other .txt files remain .pl.txt.
    stem, ext = os.path.splitext(path)
    if stem.lower().endswith('.pl'):
        return path
    if ext.lower() == '.txt':
        try:
            with open(path, 'rb') as inp:
                sample = inp.read(8192).decode('utf-8-sig', 'replace')
            import re
            if re.search(r'\d{2}:\d{2}:\d{2}[,.]\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}', sample):
                ext = '.srt'
        except OSError:
            pass
    return stem + '.pl' + ext


def log(msg):
    xbmc.log('[MultiNapisyPl cache] ' + str(msg), xbmc.LOGINFO)

def source_key():
    try:
        source = xbmc.Player().getPlayingFile()
    except Exception:
        return None
    if not source:
        return None
    # Do not use just title/year: different releases may require different subtitles.
    # Strip URL query tokens that are often renewed by streaming providers.
    try:
        p = urlsplit(source)
        if p.scheme in ('http', 'https'):
            source = urlunsplit((p.scheme, p.netloc, p.path, '', ''))
    except Exception:
        pass
    data = [source, xbmc.getInfoLabel('VideoPlayer.TVShowTitle'),
            xbmc.getInfoLabel('VideoPlayer.Season'), xbmc.getInfoLabel('VideoPlayer.Episode'),
            xbmc.getInfoLabel('VideoPlayer.Title')]
    return hashlib.sha256(json.dumps(data, ensure_ascii=False).encode('utf-8')).hexdigest()

def path_for(key):
    return os.path.join(STORE, key + '.json')

def remember(files):
    if not ADDON.getSettingBool('auto_saved_subtitles'):
        return
    key = source_key()
    if not key:
        log('No playback source: not caching')
        return
    for f in files:
        if not f or os.path.splitext(str(f))[1].lower() not in EXTENSIONS:
            continue
        try:
            src = xbmcvfs.translatePath(f)
            if not os.path.isfile(src):
                continue
            os.makedirs(STORE, exist_ok=True)
            ext = os.path.splitext(src)[1].lower()
            target = polish_filename(os.path.join(STORE, key + ext))
            tmp = target + '.new'
            shutil.copyfile(src, tmp)
            os.replace(tmp, target)
            meta = {'file': os.path.basename(target), 'language': 'pl'}
            with LOCK:
                metatmp = path_for(key) + '.new'
                with open(metatmp, 'w', encoding='utf-8') as out:
                    json.dump(meta, out)
                os.replace(metatmp, path_for(key))
            log('Saved subtitle for source: ' + key[:12])
            return
        except Exception as e:
            log('Save failed: ' + repr(e))

def get_saved(key):
    if not key:
        return None
    try:
        with open(path_for(key), encoding='utf-8') as inp:
            filename = json.load(inp)['file']
        if os.path.basename(filename) != filename:
            return None
        target = os.path.join(STORE, filename)
        return target if os.path.isfile(target) else None
    except (OSError, ValueError, KeyError, TypeError):
        return None


def forget(key):
    """Remove only the cached subtitle for one exact playback source."""
    if not key:
        return
    with LOCK:
        candidates = set()
        try:
            with open(path_for(key), encoding='utf-8') as inp:
                filename = json.load(inp).get('file', '')
            if filename and os.path.basename(filename) == filename:
                candidates.add(os.path.join(STORE, filename))
        except (OSError, ValueError, TypeError, AttributeError):
            pass
        # Remove orphaned files for this key, including alternate formats.
        if os.path.isdir(STORE):
            for name in os.listdir(STORE):
                if name.startswith(key + '.') and not name.endswith('.json'):
                    candidates.add(os.path.join(STORE, name))
        for path in candidates:
            try:
                os.remove(path)
            except FileNotFoundError:
                pass
        try:
            os.remove(path_for(key))
        except FileNotFoundError:
            pass
    log('Forgot saved subtitle for source: ' + key[:12])
