# -*- coding: utf-8 -*-
"""Check provider credentials after Kodi saves addon settings; no credentials logged."""
import os,sys,time,json,threading
from urllib.request import Request,urlopen,build_opener,HTTPCookieProcessor
from urllib.error import HTTPError,URLError
from urllib.parse import urlencode
from http.cookiejar import CookieJar
import xbmc,xbmcaddon,xbmcgui,xbmcvfs

ADDON=xbmcaddon.Addon('service.subtitles.multinapisypl')

def n24_login(username,password):
    # Isolated cookie jar, never trust previously authenticated cookies.
    from bs4 import BeautifulSoup
    base='https://napisy24.pl'
    opener=build_opener(HTTPCookieProcessor(CookieJar()))
    headers={'User-Agent':'Mozilla/5.0 (Kodi MultiNapisyPl)','Accept':'text/html'}
    with opener.open(Request(base+'/cb-login',headers=headers),timeout=12) as response:
        page=response.read().decode('utf-8','replace')
    form=BeautifulSoup(page,'html.parser').find('form',attrs={'id':'login-form'})
    if form is None:return None,'Nie można odczytać formularza logowania'
    data={'username':username,'passwd':password,'Submit':''}
    for field in form.find_all('input',attrs={'type':'hidden'}):
        if field.get('name'):data[field['name']]=field.get('value','')
    with opener.open(Request(base+'/cb-login',data=urlencode(data).encode('utf-8'),headers={**headers,'Content-Type':'application/x-www-form-urlencoded'}),timeout=12) as response:
        result=response.read().decode('utf-8','replace')
    if base+'/cb-logout' in result:return True,'Poprawnie zalogowano'
    return False,'Logowanie odrzucone — sprawdź login i hasło'

def check(provider,username,password):
    if not username or not password:return None,'Uzupełnij login i hasło'
    try:
        return n24_login(username,password)
    except (URLError,TimeoutError,OSError) as e:
        return None,'Nie można połączyć się z serwisem'
    except Exception as e:
        xbmc.log('[MultiNapisyPl] Sprawdzanie logowania '+provider+': '+type(e).__name__,xbmc.LOGWARNING)
        return None,'Nie udało się sprawdzić logowania'

def show(provider,result,message):
    name='n24' if provider=='n24' else 'os'
    heading='MultiNapisyPl — '+name
    icon=xbmcgui.NOTIFICATION_INFO if result is None else (xbmcgui.NOTIFICATION_ERROR if not result else xbmcgui.NOTIFICATION_INFO)
    xbmcgui.Dialog().notification(heading,message,icon,5500)

class Monitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.changed=threading.Event()
    def onSettingsChanged(self):self.changed.set()

def main():
    monitor=Monitor()
    keys=('username','password')
    last=tuple(ADDON.getSetting(k) for k in keys)
    pending={}
    while not monitor.abortRequested():
        monitor.waitForAbort(0.8)
        now=tuple(ADDON.getSetting(k) for k in keys)
        if now!=last:
            for provider,indices in (('n24',(0,1)),):
                if any(now[i]!=last[i] for i in indices):pending[provider]=time.monotonic()+2.0
            last=now
        for provider,due in list(pending.items()):
            if time.monotonic()<due:continue
            del pending[provider]
            i,j=0,1
            result,message=check(provider,now[i].strip(),now[j])
            show(provider,result,message)

if __name__=='__main__':main()
