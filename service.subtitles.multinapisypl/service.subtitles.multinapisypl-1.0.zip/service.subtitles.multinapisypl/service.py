# -*- coding: utf-8 -*-
"""MultiNapisyPl 1.0.43 TEST — parallel sources, standard Kodi subtitle dialog."""
import os,sys,json,re,traceback,threading,importlib,time
from urllib.parse import parse_qs,quote,unquote
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs

ADDON=xbmcaddon.Addon()
ID=ADDON.getAddonInfo('id')
PROFILE=xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
sys.path.insert(0,os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('path')),'resources','lib'))

def log(s): xbmc.log('[MultiNapisyPl] '+str(s),xbmc.LOGINFO)
def safe(s): return str(s or '')
def get_item(params):
    playing=''
    try: playing=xbmc.Player().getPlayingFile()
    except Exception: pass
    title=xbmc.getInfoLabel('VideoPlayer.OriginalTitle') or xbmc.getInfoLabel('VideoPlayer.Title')
    item=dict(title=title,tvshow=xbmc.getInfoLabel('VideoPlayer.TVShowTitle'),year=xbmc.getInfoLabel('VideoPlayer.Year'),season=xbmc.getInfoLabel('VideoPlayer.Season'),episode=xbmc.getInfoLabel('VideoPlayer.Episode'),file_original_path=unquote(playing),file_original_name=os.path.basename(playing),videoplayer_title=xbmc.getInfoLabel('VideoPlayer.Title'),temp=playing.startswith('http'),rar=False,automatic=params['action']=='search',uniqueids={})
    if params['action']=='manualsearch' and params.get('searchstring'):
        q=params['searchstring'];item['tvshow' if item['season'] and item['episode'] else 'title']=q
    item['3let_language']=[xbmc.convertLanguage(x,xbmc.ISO_639_2) for x in params.get('languages','Polish').split(',')]
    item['preferredlanguage']=xbmc.convertLanguage(params.get('preferredlanguage','Polish'),xbmc.ISO_639_2)
    try: item['file_original_size']=xbmcvfs.File(playing).size()
    except Exception: item['file_original_size']=0
    try:
        j=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Player.GetItem','params':{'playerid':1,'properties':['uniqueid','showtitle']}})))
        item['uniqueids']=j.get('result',{}).get('item',{}).get('uniqueid',{}) or {}
        item['rpc_showtitle']=j.get('result',{}).get('item',{}).get('showtitle','')
    except Exception: pass
    return item

def collapse_napisy24(rows):
    """One Napisy24 subtitle ID may advertise multiple release names.

    Keep the release matching the playing file when possible, otherwise the
    first result. Never merge distinct subtitle IDs.
    """
    grouped = {}
    order = []
    for row in rows:
        key = row.get('key')
        if not key:
            order.append((None, row))
            continue
        if key not in grouped:
            grouped[key] = {'row': dict(row), 'count': 1}
            order.append((key, None))
        else:
            entry = grouped[key]
            entry['count'] += 1
            if row.get('sync') and not entry['row'].get('sync'):
                entry['row'] = dict(row)
    output = []
    for key, row in order:
        if key is None:
            output.append(row)
        else:
            entry = grouped[key]
            chosen = entry['row']
            output.append(chosen)
    log('Napisy24: %d release entries -> %d unique subtitle IDs' % (len(rows), len(output)))
    return output

def tmdb_movie_titles(item):
    """Resolve verified movie title variants from TMDb; never guess translations."""
    if item.get('tvshow') or (item.get('season') and item.get('episode')):
        return []
    key=(ADDON.getSetting('tmdb_api_key') or '').strip()
    if not key:
        log('TMDb: brak klucza w ustawieniach MultiNapisyPl')
        return []
    try:
        from urllib.request import Request,urlopen
        from urllib.parse import urlencode
        import unicodedata
        def norm(v):
            v=unicodedata.normalize('NFKD',str(v or '')).casefold()
            return re.sub(r'[^\w]+',' ',''.join(c for c in v if not unicodedata.combining(c))).strip()
        def fetch(endpoint,params=None):
            q=dict(params or {});q['api_key']=key
            url='https://api.themoviedb.org/3/'+endpoint+'?'+urlencode(q)
            with urlopen(Request(url,headers={'User-Agent':'MultiNapisyPl/1.0.12'}),timeout=6) as r:
                return json.loads(r.read(1024*1024).decode('utf-8'))
        ids=item.get('uniqueids') or {}
        movie_id=str(ids.get('tmdb') or '')
        if not movie_id.isdigit():
            imdb=str(ids.get('imdb') or xbmc.getInfoLabel('VideoPlayer.IMDBNumber') or '')
            if re.fullmatch(r'tt\d+',imdb):
                found=fetch('find/'+imdb,{'external_source':'imdb_id'}).get('movie_results',[])
                if len(found)==1:movie_id=str(found[0].get('id') or '')
        if not movie_id.isdigit():
            title=item.get('title') or ''
            year=str(item.get('year') or '')
            results=fetch('search/movie',{'query':title}).get('results',[])
            exact=[r for r in results if norm(title) in (norm(r.get('title')),norm(r.get('original_title'))) and (not year.isdigit() or str(r.get('release_date') or '').startswith(year))]
            if len(exact)==1:movie_id=str(exact[0].get('id') or '')
        if not movie_id.isdigit():
            log('TMDb: nie znaleziono jednoznacznego filmu dla '+repr(item.get('title')))
            return []
        movie=fetch('movie/'+movie_id,{'append_to_response':'alternative_titles'})
        year=str(item.get('year') or '')
        if year.isdigit() and not str(movie.get('release_date') or '').startswith(year):
            log('TMDb: niezgodny rok dla '+repr(item.get('title')))
            return []
        names=[]
        for v in (item.get('title'),movie.get('title'),movie.get('original_title')):
            if v and norm(v) not in [norm(x) for x in names]:names.append(v)
        for lang in ('en-US','pl-PL'):
            translated=fetch('movie/'+movie_id,{'language':lang}).get('title')
            if translated and norm(translated) not in [norm(x) for x in names]:names.append(translated)
        for alt in (movie.get('alternative_titles') or {}).get('titles',[]):
            # TMDb stores legitimate release titles in many countries.
            # Do not restrict to PL/US/GB: e.g. a provider may use a French title.
            v=alt.get('title')
            if v and norm(v) not in [norm(x) for x in names]:names.append(v)
        log('TMDb: warianty tytulow filmu: '+repr(names))
        return names
    except Exception as e:
        log('TMDb: blad pobierania tytulow: '+repr(e))
        return []

def tmdb_identity_verifier(item):
    """Verify a provider's unlisted title against the SAME TMDb movie ID.

    Never accept a candidate based only on a similar title or matching year.
    Failed lookups fail closed. The cache avoids repeated HTTP requests.
    """
    key=(ADDON.getSetting('tmdb_api_key') or '').strip()
    if not key or item.get('tvshow') or not str(item.get('year') or '').isdigit():
        return None
    from urllib.request import Request,urlopen
    from urllib.parse import urlencode
    import unicodedata
    def norm(v):
        v=unicodedata.normalize('NFKD',str(v or '')).casefold()
        return re.sub(r'[^\w]+',' ',''.join(c for c in v if not unicodedata.combining(c))).strip()
    def fetch(endpoint,params=None):
        q=dict(params or {})
        headers={'User-Agent':'MultiNapisyPl/1.0.16'}
        if key.startswith('eyJ'):headers['Authorization']='Bearer '+key
        else:q['api_key']=key
        url='https://api.themoviedb.org/3/'+endpoint+'?'+urlencode(q)
        with urlopen(Request(url,headers=headers),timeout=5) as r:
            return json.loads(r.read(1024*1024).decode('utf-8'))
    year=str(item.get('year'))
    ids=item.get('uniqueids') or {}
    try:
        movie_id=str(ids.get('tmdb') or '')
        if not movie_id.isdigit():
            imdb=str(ids.get('imdb') or xbmc.getInfoLabel('VideoPlayer.IMDBNumber') or '')
            if re.fullmatch(r'tt\d+',imdb):
                hits=fetch('find/'+imdb,{'external_source':'imdb_id'}).get('movie_results',[])
                if len(hits)==1:movie_id=str(hits[0].get('id') or '')
        if not movie_id.isdigit():
            title=item.get('title') or ''
            hits=fetch('search/movie',{'query':title}).get('results',[])
            exact=[h for h in hits if norm(title) in (norm(h.get('title')),norm(h.get('original_title'))) and str(h.get('release_date') or '').startswith(year)]
            if len(exact)==1:movie_id=str(exact[0].get('id') or '')
        if not movie_id.isdigit():return None
        actual=fetch('movie/'+movie_id)
        if not str(actual.get('release_date') or '').startswith(year):return None
    except Exception as e:
        log('N24 TMDb identity initialization unavailable: '+type(e).__name__)
        return None
    cache={}
    cache_lock=threading.Lock()
    def verify(provider_title,provider_year):
        name=re.sub(r'\s*[\[(](?:19|20)\d{2}[\])]\s*$','',str(provider_title or '')).strip()
        if provider_year and str(provider_year)!=year:return False
        k=norm(name)
        if not k:return False
        with cache_lock:
            if k in cache:return cache[k]
            # Concurrent verification for identical provider titles is rare;
            # record negative default before doing the network lookup.
            cache[k]=False
        try:
            # TMDb indexes alternative names in search, even when its
            # alternative_titles endpoint does not expose every localized alias.
            hits=fetch('search/movie',{'query':name,'year':year}).get('results',[])
            matches=[h for h in hits if str(h.get('id'))==movie_id and str(h.get('release_date') or '').startswith(year)]
            verified=bool(matches)
            with cache_lock:cache[k]=verified
            log('N24 TMDb identity: %r same movie=%s' % (name,verified))
        except Exception as e:
            log('N24 TMDb identity check unavailable: '+type(e).__name__)
        return cache[k]
    return verify

def source24(item):
    import NapisyUtils as n
    # Dane logowania N24 pochodzą wyłącznie z ustawień MultiNapisyPl.
    n.__addon__=ADDON
    n.__profile__=PROFILE
    n.__temp__=os.path.join(PROFILE,'temp')
    os.makedirs(n.__temp__,exist_ok=True)
    try:
        x=dict(item)
        n.clean_title(x);n.parse_rls_title(x)
        x['alternate_titles']=tmdb_movie_titles(item)
        x['verify_n24_title']=tmdb_identity_verifier(item)
        x['skip_n24_tmdb_lookup']=True
        results = n.NapisyHelper().get_subtitle_list(x) or []
        accepted = []
        for i in results:
            lang = str(i.get('language_name') or '').strip().casefold()
            flag = str(i.get('language_flag') or '').strip().casefold()
            # Reject English at search time; no download needed.
            release = str(i.get('filename') or '')
            # Some releases are tagged ENG despite being reported as Polish.
            # Match standalone language tags, not substrings inside titles.
            eng_release = bool(re.search(r'(?i)(?<![a-z0-9])(?:eng|english|en-us|en-gb)(?![a-z0-9])', release))
            if lang in ('english', 'angielski', 'eng', 'en') or flag in ('en', 'eng', 'en-us', 'en-gb', 'english') or eng_release:
                log('N24 FILTER: omitted English result: ' + str(i.get('filename', '')))
                continue
            accepted.append(dict(src='N24',label=i.get('filename',''),lang=i.get('language_name','Polish'),thumb=i.get('language_flag','pl'),sync=i.get('sync',False),key=str(i['id'])))
        log('N24 language filter: %d entries -> %d entries' % (len(results), len(accepted)))
        return collapse_napisy24(accepted)
    except Exception as e:log('Napisy24 error: '+repr(e));return []

def source_napi(item):
    try:
        import NapiProjekt as n
        # Użyj profilu i pamięci podręcznej samodzielnego NapiProjekt Katalog,
        # jeśli jest zainstalowany. Dzięki temu ponowne wyszukiwanie jest szybkie.
        try:
            n.__addon__=xbmcaddon.Addon('service.subtitles.napiprojektkatalog')
            n.__scriptname__='NapiProjekt Katalog'
        except Exception:
            n.__addon__=ADDON
            n.__scriptname__='MultiNapisyPl — NapiProjekt'
        x=dict(item)
        # NapiProjekt wymaga listy polskich kodów języka.
        x['3let_language']=['pol','pl']
        # Verified aliases from the same TMDb film, shared with Napisy24.
        # The NapiProjekt backend uses them only after normal title attempts fail.
        x['alternate_titles']=tmdb_movie_titles(item) if not item.get('tvshow') else []
        log('NapiProjekt search start: '+repr((x.get('title'),x.get('tvshow'),x.get('year'))))
        found=n.NapiProjektKatalog().search(x) or []
        log('NapiProjekt search returned %d entries' % len(found))
        return [dict(src='NP',label=i.get('label',''),lang='Polish',thumb='pl',sync=i.get('sync',False),key=str(i['link_hash'])) for i in found]
    except Exception as e:log('NapiProjekt error: '+repr(e));return []

def a4k_api():
    path=xbmcvfs.translatePath(xbmcaddon.Addon('service.subtitles.a4ksubtitles').getAddonInfo('path'))
    if path not in sys.path:sys.path.insert(0,path)
    from a4kSubtitles.api import A4kSubtitlesApi
    return A4kSubtitlesApi()

# a4kSubtitles API's settings= override tries to assign to Kodi's native
# xbmcaddon.Addon.getSetting, which is read-only. Use a delegating proxy instead.
# Hold the lock for the entire call so simultaneous searches/downloads do not
# temporarily replace the shared a4k Kodi addon instance.
from contextlib import contextmanager
_A4K_SETTINGS_LOCK=threading.RLock()

@contextmanager
def a4k_own_credentials(api):
    kodi=api.core.kodi
    with _A4K_SETTINGS_LOCK:
        original=kodi.addon
        overrides={'opensubtitles.username':ADDON.getSetting('os_username'),
                   'opensubtitles.password':ADDON.getSetting('os_password')}
        class SettingsProxy:
            def __init__(self,addon):self._addon=addon
            def getSetting(self,key):
                if key in overrides:return overrides[key]
                return self._addon.getSetting(key)
            def __getattr__(self,key):return getattr(self._addon,key)
        kodi.addon=SettingsProxy(original)
        try:yield
        finally:kodi.addon=original

def source_os(item,params):
    try:
        api=a4k_api()
        with a4k_own_credentials(api):
            rows=api.search(dict(languages=params.get('languages','Polish'),preferredlanguage=params.get('preferredlanguage','Polish'))) or []
        return [dict(src='OS',label=i.get('name',''),lang='Polish',thumb='pl',sync=i.get('sync') in ('true',True),key=json.dumps(i,ensure_ascii=False)) for i in rows if 'opensubtitles' in i.get('service_name','').lower()]
    except Exception as e:log('a4k OpenSubtitles error: '+repr(e));return []

def search(params, interactive=False):
    if params.get('refresh') == '1':
        try:
            from subtitle_cache import source_key, forget
            key = source_key()
            if key:
                forget(key)
                log('Direct search refresh: cleared saved subtitles for current source')
        except Exception as exc:
            log('Direct search refresh cache removal failed: ' + repr(exc))
    collected = []
    # Kodi/other subtitle managers may request an automatic search even after
    # our playback service has restored a saved subtitle. Never re-query the
    # providers in that case; manualsearch must always remain available.
    if not interactive and params.get('action') == 'search' and ADDON.getSettingBool('auto_saved_subtitles'):
        try:
            from subtitle_cache import source_key, get_saved
            key = source_key()
            saved = get_saved(key) if key else None
            if saved:
                # SubLoader opens Kodi's normal subtitle search dialog. Show a
                # status row there rather than leaving the dialog empty.
                player = xbmc.Player()
                try:
                    active = bool(player.getSubtitles()) and player.isSubtitlesEnabled()
                except Exception:
                    active = False
                if not active:
                    try:
                        player.setSubtitles(saved)
                        player.showSubtitles(True)
                        log('Saved subtitles applied from automatic search')
                    except Exception as exc:
                        log('Saved subtitles could not be applied: ' + repr(exc))
                        # Do not claim success: fall back to normal search.
                        active = False
                    else:
                        try:
                            active = bool(player.getSubtitles()) and player.isSubtitlesEnabled()
                        except Exception:
                            active = True  # setSubtitles returned without error
                if active:
                    label = '[COLOR lime]Napisy zostały automatycznie wczytane - naciśnij, aby zamknąć okno[/COLOR]'
                    li = xbmcgui.ListItem(label=label, label2='MultiNapisyPl — zapisane napisy')
                    li.setProperty('sync', 'true')
                    xbmcplugin.addDirectoryItem(int(sys.argv[1]),
                        'plugin://%s/?action=saved_status' % ID, li, False)
                    li2 = xbmcgui.ListItem(label='[COLOR yellow]Wyszukaj napisy ponownie[/COLOR]', label2='MultiNapisyPl — odśwież listę')
                    xbmcplugin.addDirectoryItem(int(sys.argv[1]), 'plugin://%s/?action=search&refresh=1' % ID, li2, False)
                    log('Automatic search: showing saved subtitle status and refresh action')
                    return
                log('Saved subtitle could not be confirmed; running normal search')
        except Exception as e:
            log('Automatic cache check failed: ' + repr(e))
    item=get_item(params)
    providers=[('Napisy24',lambda:source24(item),'napisy24'),('OpenSubtitles',lambda:source_os(item,params),'opensubtitles'),('NapiProjekt',lambda:source_napi(item),'napiprojekt')]
    import queue
    completed=queue.Queue()
    active=[]
    counts={}
    started={}
    elapsed={}
    def worker(name,func):
        try:
            rows=func() or []
            completed.put((name,rows,None))
        except Exception as e:
            completed.put((name,[],repr(e)))
    for name,fn,setting in providers:
        if ADDON.getSetting(setting)=='false':continue
        started[name]=time.monotonic()
        t=threading.Thread(target=worker,args=(name,fn),daemon=True)
        t.start();active.append((name,t))
    # Kodi displays the native subtitle picker only after endOfDirectory.
    # Show cancellable progress while providers work; keep completed results.
    pending={name for name,_ in active}
    deadline=__import__('time').monotonic()+90
    progress=xbmcgui.DialogProgress()
    progress.create('MultiNapisyPl', 'Wyszukiwanie napisów...')
    def append_results(name,rows,error):
        if name not in pending:return
        pending.remove(name)
        elapsed[name]=time.monotonic()-started[name]
        log("%s search duration: %.2f s" % (name,elapsed[name]))
        if error:log(name+' error: '+error)
        counts[name]=len(rows)
        for row in rows:
            label='[[B]%s[/B]] %s'%({'Napisy24':'n24','OpenSubtitles':'os','NapiProjekt':'NP'}.get(name,name),row['label'])
            # Kodi uses the subtitle search result's primary label to name its
            # first downloaded copy (UUID.<language>.srt). An empty label
            # produced UUID..srt and an unknown language on first load.
            language = row.get('lang') or 'Polish'
            li=xbmcgui.ListItem(label=language,label2=label)
            li.setArt({'icon':'5','thumb':row['thumb']})
            if row['sync']:li.setProperty('sync','true')
            uri='plugin://%s/?action=download&source=%s&key=%s'%(ID,quote(row['src']),quote(row['key'],safe=''))
            if interactive:
                collected.append((label, row))
            else:
                xbmcplugin.addDirectoryItem(int(sys.argv[1]),uri,li,False)
        log('%s completed: %d; remaining: %s' % (name,len(rows),', '.join(sorted(pending))))
    def update_progress():
        done=len(active)-len(pending)
        fs_warning = False
        if "NapiProjekt" in pending:
            try:
                import NapiProjekt as np_module
                fs_warning = bool(getattr(np_module, "_FS_SERVER_ERROR", False))
            except Exception:
                pass
        def provider_status(name):
            if name not in started:
                return 'Wyłączony'
            if name in pending:
                return 'Trwa... (%.1f s)' % (time.monotonic()-started[name])
            return '%d znalezionych (%.1f s)' % (counts.get(name,0),elapsed.get(name,0))
        progress.update(int(100*done/max(1,len(active))),
                        'Znaleziono: %d | Zakończono: %d/%d\n[[B]os[/B]]: %s\n[[B]n24[/B]]: %s\n[[B]NP[/B]]: %s' % (
                            sum(counts.values()),done,len(active),
                            provider_status('OpenSubtitles'),
                            provider_status('Napisy24'),
                            provider_status('NapiProjekt') + (' [COLOR red]Problem z serwerem FS[/COLOR]' if fs_warning else '')))
    cancelled=False
    try:
        update_progress()
        while pending and time.monotonic()<deadline:
            # Cancellation stops waiting, not the background network requests.
            if progress.iscanceled():
                log('Search cancelled by user; retaining completed results')
                cancelled=True
                break
            try:
                name,rows,error=completed.get(timeout=0.2)
                append_results(name,rows,error)
            except queue.Empty:pass
            update_progress()
        # Drain already finished tasks so Cancel never discards results ready in queue.
        while True:
            try:name,rows,error=completed.get_nowait()
            except queue.Empty:break
            append_results(name,rows,error)
        update_progress()
        # Keep the final per-provider times visible for 1.5 seconds.
        # Never delay an explicit cancellation or a search that timed out.
        if not cancelled and not pending:
            hold_until=time.monotonic()+1.5
            while time.monotonic()<hold_until:
                if progress.iscanceled():
                    break
                time.sleep(min(0.1, max(0,hold_until-time.monotonic())))
    finally:
        progress.close()
    if pending:log('Search ended with providers pending: '+', '.join(sorted(pending)))
    log('Search complete: '+repr(counts))
    return collected

def _confidently_english_srt(path):
    """Conservative content check; ambiguous/mixed subtitles are not rejected."""
    try:
        if not path.lower().endswith(('.srt', '.txt', '.sub', '.vtt')):
            return False
        with open(path, 'rb') as f:
            raw=f.read(140000)
        text=None
        for encoding in ('utf-8-sig','utf-16','cp1250','windows-1252'):
            try:
                text=raw.decode(encoding)
                break
            except UnicodeError:
                continue
        if not text:
            return False
        text=re.sub(r'<[^>]+>|\{\\[^}]+\}', ' ', text)
        text=re.sub(r'(?m)^\s*(?:\d+|\d\d:\d\d:\d\d[,.]\d+.*|WEBVTT)\s*$', ' ', text)
        words=re.findall(r"[a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ']+",text.lower())
        if len(words)<90:
            return False
        en=set('the and you your are have that this with what from they there would could should about just dont know were them when where because really going want need think something'.split())
        pl=set('się nie jest jak ale tak tego tylko mnie ciebie jego jej żeby który która które przez bardzo będę jesteś jestem mamy mają można tutaj dlaczego jeszcze teraz przecież kiedy gdzie zawsze'.split())
        en_hits=sum(w in en for w in words)
        pl_hits=sum(w in pl for w in words)
        # High margin avoids rejecting mixed-language and uncertain files.
        return en_hits>=22 and en_hits>=pl_hits*5 and en_hits/len(words)>=0.09
    except Exception as exc:
        log('N24 language content check unavailable: '+repr(exc))
        return False

def download(params, direct=False):
    src=params.get('source');key=params.get('key','');files=[]
    try:
        if src=='N24':
            import NapisyUtils as n
            n.__addon__=ADDON
            n.__profile__=PROFILE
            n.__temp__=os.path.join(PROFILE,'temp')
            os.makedirs(n.__temp__,exist_ok=True)
            files=n.NapisyHelper().download(key) or []
            # Do not block downloads based on heuristic language detection:
            # it can misclassify short Polish subtitles and return no file.
        elif src=='NP':
            import NapiProjekt as n
            try:n.__addon__=xbmcaddon.Addon('service.subtitles.napiprojektkatalog')
            except Exception:n.__addon__=ADDON
            target=os.path.join(PROFILE,'temp','napiprojekt.zip')
            os.makedirs(os.path.dirname(target),exist_ok=True)
            f=n.NapiProjektKatalog().download(key,target,'PL')
            files=[f] if f else []
        elif src=='OS':
            row=json.loads(key)
            api=a4k_api()
            with a4k_own_credentials(api):
                f=api.download({'service_name':row['service_name'],'action_args':row['action_args']})
            files=[f] if f else []
    except Exception as e:log('Download error: '+repr(e)+' '+traceback.format_exc())
    if files:
        try:
            from subtitle_cache import remember
            remember(files)
        except Exception as e:log('Cache error: '+repr(e))
    if direct:
        return [f for f in files if f]
    for f in files:
        if f:
            li=xbmcgui.ListItem(label=f)
            xbmcplugin.addDirectoryItem(int(sys.argv[1]),f,li,False)

def refresh_saved():
    """Forget saved subtitles, then reopen Kodi native picker once."""
    try:
        from subtitle_cache import source_key, forget
        key = source_key()
        if key:
            forget(key)
            log('Refresh: cleared saved subtitles for current source')
        else:
            log('Refresh: no source key; continuing with native search')
    except Exception as exc:
        log('Refresh cache removal failed: ' + repr(exc))
    # Kodi closes the current subtitle dialog when a row is selected.
    # Do not run search here: Kodi would discard its results and close the dialog.
    log('Refresh: cache cleared; wait for Kodi to close selected row, then reopen native subtitle search once')
    # Kodi closes its subtitle dialog after activating a download-style row.
    # Reopen the native dialog after Kodi has finished processing the click.
    # AlarmClock runs on Kodi's main loop, not on this short-lived Python script.
    try:
        xbmc.executebuiltin('AlarmClock(MultiNapisyPlReopen,ActivateWindow(subtitlesearch),00:02,silent)')
        log('Refresh: scheduled native subtitle dialog reopen in 2 seconds')
    except Exception as exc:
        log('Refresh: failed to schedule subtitle dialog reopen: ' + repr(exc))

if __name__=='__main__':
    try:
        params={k:v[0] for k,v in parse_qs(sys.argv[2].lstrip('?')).items()}
        if params.get('action') in ('search','manualsearch'):search(params)
        elif params.get('action')=='download':download(params)
        elif params.get('action')=='refresh_saved':refresh_saved()
        elif params.get('action')=='saved_status':
            # Kodi treats an OK click as a subtitle download request.
            # Return the already cached subtitle path as a normal download result,
            # rather than closing the dialog with an empty result (which triggers
            # the misleading 'subtitle download failed' notification).
            try:
                from subtitle_cache import source_key, get_saved
                key = source_key()
                saved = get_saved(key) if key else None
                if saved and xbmcvfs.exists(saved):
                    li = xbmcgui.ListItem(label=saved)
                    xbmcplugin.addDirectoryItem(int(sys.argv[1]), saved, li, False)
                    log('Saved subtitle returned to Kodi after OK: ' + saved)
                else:
                    log('Saved subtitle missing after OK; no download result')
            except Exception as exc:
                log('Saved subtitle OK handling failed: ' + repr(exc))
    except Exception as e:log('Fatal '+repr(e)+' '+traceback.format_exc())
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
